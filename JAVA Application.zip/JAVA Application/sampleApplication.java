import java.util.HashMap;
import java.util.Random;  
import com.sun.net.httpserver.HttpServer;

import java.io.*;  
import java.net.InetSocketAddress;
import java.lang.Thread;
import java.net.HttpURLConnection;
import java.net.URL;
public class sampleApplication   
{  

public static long RandomGenerator() {
	Random random = new Random();  
	long y = random.nextInt(10000000);   
	System.out.println("Randomly Generated Integers Value :" +y);
	return y;
  }


public static void StringReverser(long number, long reverse) {
    while(number != 0)   
	{  
	long remainder = number % 10;  
	reverse = reverse * 10 + remainder;  
	number = number/10;  
	}  
	System.out.println("The reverse of the given number is: " + reverse);  
  }
  
  
public static void PalindromeChecker(long n) {
    long num, r,
        rev = 0;
        num = n;
        while (num > 0)
        {
            r = num % 10;
            rev = (rev * 10) + r;
            num = num / 10;
        }
        if (n == rev)
        {
            System.out.println("Palindrome Number");
        }
        else
        {
            System.out.println("Not Palindrome Number");
        }
  }
  
public static void method() throws FileNotFoundException {  
  
        FileReader file = new FileReader("C:\\Users\\Anurati\\Desktop\\abc.txt");  
        BufferedReader fileInput = new BufferedReader(file);  
  
      
        throw new FileNotFoundException();  
      
    } 
	
	public static void checkSocket() throws IOException{  
  
       String USER_AGENT = "Mozilla/5.0";
URL obj = new URL("http://localhost:8080/api/greeting");
HttpURLConnection con = (HttpURLConnection) obj.openConnection();
con.setRequestMethod("GET");
con.setRequestProperty("User-Agent", USER_AGENT);
int responseCode = con.getResponseCode();
System.out.println("+++++++GET Response Code :: " + responseCode);
      
    } 
	
public static void SocketCreator()throws IOException{  
  
HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        server.createContext("/api/greeting", (exchange -> {

            if ("GET".equals(exchange.getRequestMethod())) {
                String responseText = "Hello World! \n";
                exchange.sendResponseHeaders(200, responseText.getBytes().length);
                OutputStream output = exchange.getResponseBody();
                output.write(responseText.getBytes());
                output.flush();
            } else {
                exchange.sendResponseHeaders(405, -1);// 405 Method Not Allowed
            }
            exchange.close();
        }));
		
		server.createContext("/api/closing", (exchange -> {

    String method = exchange.getRequestMethod();

    if ("GET".equalsIgnoreCase(method)) {
        String responseText = "Good Bye !!\n";
        exchange.sendResponseHeaders(200, responseText.getBytes().length);
        try (OutputStream output = exchange.getResponseBody()) {
            output.write(responseText.getBytes());
        }
    } else if ("POST".equalsIgnoreCase(method)) {
        // Handle POST request
        String responseText = "Post Request Received!\n";
        exchange.sendResponseHeaders(200, responseText.getBytes().length);
        try (OutputStream output = exchange.getResponseBody()) {
            output.write(responseText.getBytes());
        }
    } else {
        // Unsupported method
        exchange.sendResponseHeaders(405, -1); // 405 Method Not Allowed
    }
    exchange.close();
}));


        server.setExecutor(null); // creates a default executor
        server.start(); 		
      
    }
  
  
public static void main(String[] args)throws IOException{



while(true){
	try{
	try{
		SocketCreator();
}
catch(Exception e){System.out.println(e);}

		try{
			checkSocket();
	}
catch(Exception e){System.out.println(e);}

	long number = RandomGenerator();
	long reverse = 0; 
	StringReverser(number,reverse); 
	PalindromeChecker(number);
	try  
        {  
            method();  
        }   
        catch (FileNotFoundException e)   
        {  
            e.printStackTrace();  
        }
	Thread.sleep(1000); 
	
	}
catch (Exception e) {
           
            // catching the exception
            System.out.println(e);
        }

}


}
}  